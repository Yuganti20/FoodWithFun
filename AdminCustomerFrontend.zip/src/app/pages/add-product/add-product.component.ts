import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit{
  productObj: any;
  productListObj : any [];

  constructor(){
    this.productListObj=[];
  this.productObj ={
    "productId": 0,
    "productName": "",
    "productPrice": 0,
    "productImgUrl": "",
    "productCategory": "",
    "createdOn" : new Date
  }
  }
ngOnInit(): void {
this.loadProducts();
}
loadProducts(){
  const isData = localStorage.getItem('productData');
  if (isData != null) {
    const oldData = JSON.parse(isData);
    this.productListObj = oldData;
  }
}
saveProduct(){
  const isData = localStorage.getItem('productData');
    if (isData != null) {
      const oldData = JSON.parse(isData);
      if(this.productObj.productId != 0){

        const productIndex = oldData.find((x:any) => x.productId == this.productObj.productId);
        if (productIndex != null && productIndex != undefined) {
          productIndex.productName=this.productObj.productName;
          productIndex.productPrice=this.productObj.productPrice;
          productIndex.productImgUrl=this.productObj.productImgUrl;
          productIndex.productCategory=this.productObj.productCategory;

         localStorage.setItem('productData',JSON.stringify(oldData));
         alert("Product Updated Successfully");
        }
      }else{
      const newId = oldData.length + 1;
      this.productObj.productId = newId;
      oldData.push(this.productObj);
      localStorage.setItem('productData',JSON.stringify(oldData));
      alert("Product Added Successfully");
      }
    }else{
      let arr: any = [];
      this.productObj.productId = 1;
      arr.push(this.productObj);
      localStorage.setItem('productData',JSON.stringify(arr));
      alert("Product Added Successfully");
    }

    this.loadProducts();
    this.productObj ={
      "productId": 0,
      "productName": "",
      "productPrice": 0,
      "productImgUrl": "",
      "productCategory": "",
      "createdOn" : new Date
    }
}
onEdit(item:any){
  this.productObj = item;
}
onDelete(item:any){
  const isDelete = confirm("Are you sure to delete record?");
  if(isDelete){
    const isData = localStorage.getItem('productData');
    if(isData != null){
      const localData = JSON.parse(isData);
      for(let index=0; index < localData.length; index++){
        if(localData[index].productId == item.productId){
          localData.splice(index,1);
        }
      }
      localStorage.setItem('productData',JSON.stringify(localData));
      this.loadProducts();
    }
  }
}
onCancel(){
  this.productObj ={
    "productId": 0,
    "productName": "",
    "productPrice": 0,
    "productImgUrl": "",
    "productCategory": "",
    "createdOn" : new Date
  }
}
}
