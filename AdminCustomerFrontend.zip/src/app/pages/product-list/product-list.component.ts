import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit{
  productListObj : any [];

  constructor(){
this.productListObj=[];
  }
ngOnInit(): void {
  this.loadProducts();
}
loadProducts(){
  const isData = localStorage.getItem('productData');
  if (isData != null) {
    const oldData = JSON.parse(isData);
    this.productListObj = oldData;
  }
}
}
