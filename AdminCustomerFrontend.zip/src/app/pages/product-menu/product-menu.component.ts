import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-menu',
  templateUrl: './product-menu.component.html',
  styleUrls: ['./product-menu.component.css']
})
export class ProductMenuComponent implements OnInit{
  objProductList : any [];

  constructor(){
    this.objProductList=[];
  }
ngOnInit(): void {
  this.loadProducts();
}
loadProducts(){
  const isData = localStorage.getItem('productData');
  if (isData != null) {
    const oldData = JSON.parse(isData);
    this.objProductList = oldData;
  }
}
}
