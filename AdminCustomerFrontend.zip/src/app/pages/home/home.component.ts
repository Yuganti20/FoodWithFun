import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{
  registerObj : any;
  adminEmail : string= "";
  adminPwd : string= "";
  customerObj : any;
  customerEmail :string= "";
  customerPwd : string = "";
  loggedUser : string;

  constructor(private router:Router){
    this.loggedUser = "";
this.registerObj = {
  "id":0,
  "name": "",
  "mobileNo":"",
  "email":"",
  "password":""
}
this.customerObj = {
  "custId":0,
  "custName": "",
  "custMobileNo":"",
  "custEmail":"",
  "custPassword":""
}
  }
ngOnInit(): void {
}
openRegisterAdmin(){
  document.getElementById('registerAdmin').style.display = 'block';
}
closeRegisterAdmin(){
  document.getElementById('registerAdmin').style.display = 'none';
  this.registerObj = {
    "id":0,
    "name": "",
    "mobileNo":"",
    "email":"",
    "password":""
  }
}
onSave(){
const isData = localStorage.getItem('adminData');
    if (isData != null) {
      const oldData = JSON.parse(isData);
      const newId = oldData.length + 1;
      this.registerObj.id = newId;
      oldData.push(this.registerObj);
      localStorage.setItem('adminData',JSON.stringify(oldData));
    }else{
      let arr: any = [];
      this.registerObj.id = 1;
      arr.push(this.registerObj);
      localStorage.setItem('adminData',JSON.stringify(arr));
    }
    alert("Registered Successfully");
    this.registerObj = {
      "id":0,
      "name": "",
      "mobileNo":"",
      "email":"",
      "password":""
    }
    document.getElementById('registerAdmin').style.display = 'none';
}
openLoginAdmin(){
  document.getElementById('loginAdmin').style.display = 'block';
}
closeLoginAdmin(){
  document.getElementById('loginAdmin').style.display = 'none';
}
onAdminLogin(){
  const isData = localStorage.getItem('adminData');
    if (isData != null) {
      const oldData = JSON.parse(isData);
      const isAdmin = oldData.find(m=>m.email==this.adminEmail && m.password == this.adminPwd);
      if(isAdmin != null){
        this.router.navigateByUrl('addProduct');
        this.loggedUser = 'admin';
        localStorage.setItem('LoggedUser', JSON.stringify(this.loggedUser));
      }else{
        alert("Check email or password");
      }
    }else{
      alert("Please Do Register");
    }
}

//-----------For Customer ---------------------------//
openRegisterCustomer(){
  document.getElementById('registerCustomer').style.display = 'block';
}
closeRegisterCustomer(){
  document.getElementById('registerCustomer').style.display = 'none';
  this.customerObj = {
    "custId":0,
    "custName": "",
    "custMobileNo":"",
    "custEmail":"",
    "custPassword":""
  }
}
onRegCustomer(){
  const isData = localStorage.getItem('customerData');
  if (isData != null) {
    const oldData = JSON.parse(isData);
    const newId = oldData.length + 1;
    this.customerObj.custId = newId;
    oldData.push(this.customerObj);
    localStorage.setItem('customerData',JSON.stringify(oldData));
  }else{
    let arr: any = [];
    this.customerObj.custId = 1;
    arr.push(this.customerObj);
    localStorage.setItem('customerData',JSON.stringify(arr));
  }
  alert("Registered Successfully");
  this.customerObj = {
    "custId":0,
    "custName": "",
    "custMobileNo":"",
    "custEmail":"",
    "custPassword":""
  }
  document.getElementById('registerCustomer').style.display = 'none';
}
openLoginCustomer(){
  document.getElementById('loginCustomer').style.display = 'block';
}
closeLoginCustomer(){
  document.getElementById('loginCustomer').style.display = 'none';
}
onCustomerLogin(){
  const isData = localStorage.getItem('customerData');
  if (isData != null) {
    const oldData = JSON.parse(isData);
    const isCustomer = oldData.find(m=>m.custEmail==this.customerEmail && m.custPassword == this.customerPwd);
    if(isCustomer != null){
      this.router.navigateByUrl('productList');
      this.loggedUser = 'customer';
      localStorage.setItem('LoggedUser', JSON.stringify(this.loggedUser));
    }else{
      alert("Check email or password");
    }
  }else{
    alert("Please Do Register");
  }
}
}
