import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LayoutComponent } from './pages/layout/layout.component';
import { AddProductComponent } from './pages/add-product/add-product.component';
import { ProductListComponent } from './pages/product-list/product-list.component';
import { ProductMenuComponent } from './pages/product-menu/product-menu.component';
import { CustomerListComponent } from './pages/customer-list/customer-list.component';

const routes: Routes = [
  {
    path:'',
    component:HomeComponent,
  },
  {
    path:'Home',
    component:HomeComponent,
  },
  {
    path:'',
    component:LayoutComponent,
    children:[
      {
        path:'addProduct',
        component:AddProductComponent
      },
      {
        path:'viewProduct',
        component:ProductListComponent
      },
      {
        path:'customerList',
        component:CustomerListComponent
      },
      {
        path:'productList',
        component:ProductMenuComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
