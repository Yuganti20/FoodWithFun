// contact-us.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  name: string | undefined;
  email: string | undefined;
  message: string | undefined;
  submitted: boolean = false;

  submitForm() {
    // Perform any necessary form submission logic here (e.g., send data to backend, save to database)
    // For demonstration purposes, we'll simply set the "submitted" flag to true.
    this.submitted = true;
  }
}