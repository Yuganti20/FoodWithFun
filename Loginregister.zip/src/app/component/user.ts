export class User {
    fname!:string;
    lname!:string;
    email!:string;
    phone!:string;
    password!:string;
    gender!:string;

}
