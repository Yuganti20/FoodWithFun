// import { Component, OnInit } from '@angular/core';
// import { User } from 'src/app/class/register';
// import { RegisteruserService } from 'src/app/service/register.service';
// //import { User } from '../user';
// //mport { User } from '../user';

// @Component({
//   selector: 'app-register',
//   templateUrl: './register.component.html',
//   styleUrls: ['./register.component.css']
// })
// export class RegisterComponent implements OnInit {
//   user:User=new User();

//   constructor(private registerService:RegisteruserService) { }

//   ngOnInit(): void {
//   }

//   userRegister(){
//     console.log(this.user);
//     this.registerService.registerUser(this.user).subscribe(data=>
//       {
//       alert("Successfully User is register!!!")
//       },error=>alert("Sorry User not register"));
//   }
// }


import { Component, OnInit } from '@angular/core';
import { Register } from 'src/app/class/register';
import { RegisteruserService } from 'src/app/service/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: Register = new Register();
  registrationError: string | null = null; // To store the registration error message

  constructor(private registerService: RegisteruserService) {}

  ngOnInit(): void {}

  userRegister() {
    console.log(this.user);
    this.registerService.registerUser({ user: this.user }).subscribe(
      () => {
        // Successful registration response
        alert('Successfully User is registered!!!');
        // Optionally, you can navigate the user to the login page after successful registration.
      },
      (error): void => {
        // Error response from the backend
        if (error.status === 409) {
          this.registrationError = 'User with this email already exists. Please use a different email.';
        } else {
          this.registrationError = 'An error occurred while registering the user. Please try again later.';
        }
      }
    );
  }
}
