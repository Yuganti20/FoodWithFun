
// import { Component, OnInit } from '@angular/core';
// import { Login } from 'src/app/class/login';
// import { LoginService } from 'src/app/service/login.service';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {
//   loginuser: Login = new Login();
//   loginError: string | null = null;
//   userDetail: any; // To store the user details after successful login

//   constructor(private loginService: LoginService) {}

//   ngOnInit(): void {}

//   login() {
//     console.log(this.loginuser);
//     this.loginService.loginUser(this.loginuser).subscribe(
//       (data) => {
//         // Successful login response
//         alert('WELCOME');
//         // Store the user details locally
//         this.userDetail = data;
//         // Here, you can also handle the data returned from the backend,
//         // e.g., store the user details in a service or local storage.
//       },
//       (error): void => {
//         // Error response from the backend
//         if (error.status === 401) {
//           this.loginError = 'Invalid credentials. Please check your username and password.';
//         } else {
//           this.loginError = 'An error occurred while logging in. Please try again later.';
//         }
//       }
//     );
//   }
// }
// // import { Component, OnInit } from '@angular/core';
// // import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// // import { Router } from '@angular/router';
// // import { HttpClient } from '@angular/common/http';
// // import { LoginService } from 'src/app/service/login.service';
// // import { Login } from 'src/app/class/login';

// // @Component({
// //   selector: 'app-login',
// //   templateUrl: './login.component.html',
// //   styleUrls: ['./login.component.css']
// // })


// // export class LoginComponent implements OnInit {

// //   loginuser:Login=new Login();

// //   constructor(private loginService: LoginService) { }

// //   ngOnInit(): void {
// //   }

// //   login(){
// //     console.log(this.loginuser);
// //     this.loginService.loginUser(this.loginuser).subscribe(()=>
// //       {
// //       alert("Login Successfully")
// //       },_error=>alert("Sorry User not register"));
// //   }

 

// // }
// // export class LoginComponent implements OnInit {
// //   loginuser: Login = new Login(); // Initialize loginuser object with default values
// //   loginError: string | null = null;
// //   userDetail: any; // To store the user details after successful login

// //   constructor(private loginService: LoginService) {}

// //   ngOnInit(): void {}

// //   login() {
// //     console.log(this.loginuser);
// //     this.loginService.loginUser(this.loginuser).subscribe(
// //       (data) => {
// //         // Successful login response
// //         alert('WELCOME');
// //         this.getUserList(); // Fetch the list of registered users after successful login
// //       },
// //       (error) => {
// //         // Error response from the backend
// //         if (error.status === 401) {
// //           this.loginError = 'Invalid credentials. Please check your username and password.';
// //         } else {
// //           this.loginError = 'An error occurred while logging in. Please try again later.';
// //         }
// //       }
// //     );
// //   }

// //   getUserList() {
// //     this.loginService.getAllUsers().subscribe(
// //       (data: any) => {
// //         // Handle the user list data returned from the backend
// //         console.log(data); // For testing purposes, you can log the data in the browser console

// //         // Now you can use 'data' to display the user list on your frontend
// //         // For example, you can assign 'data' to a component variable to render it in your template
// //       },
// //       (error) => {
// //         // Handle error response from the backend (if needed)
// //         console.error(error);
// //       }
// //     );
// //   }
// // }
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Login } from '../login';
import { LoginService } from 'src/app/service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginuser:Login=new Login();

  constructor(private loginService: LoginService) { }

  ngOnInit(): void {
  }

  login(){
    console.log(this.loginuser);
    this.loginService.loginUser(this.loginuser).subscribe(data=>
      {
      alert("You are successfully login to foody Panda")
      },_error=>alert("Sorry User not register"));
  }

 

}
