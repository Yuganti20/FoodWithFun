import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from '../class/register';

@Injectable({
  providedIn: 'root'
})
export class RegisteruserService {

  baseUrl="http://localhost:8080/user"
  constructor(private httpClient:HttpClient) { }

  registerUser({ user }: { user: Register; }):Observable<object>{
    console.log(user);
    return this.httpClient.post(`${this.baseUrl}`,user);

  }
}
