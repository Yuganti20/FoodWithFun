// // import { HttpClient } from '@angular/common/http';
// // import { Injectable } from '@angular/core';
// // import { Observable } from 'rxjs';
// // import { Login } from '../class/login';

// // @Injectable({
// //   providedIn: 'root'
// // })
// // export class LoginService {
// //   baseUrl="http://localhost:8080/login"
// //   constructor(private httpClient:HttpClient) { }

// //   loginUser(user:Login):Observable<object>{
// //     console.log(user);

// //       return this.httpClient.post(`${this.baseUrl}`,user);
    
// //   }
// // }
// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { Login } from '../class/login';

// @Injectable({
//   providedIn: 'root'
// })
// export class LoginService {
//   baseUrl = "http://localhost:8080/login";

//   constructor(private httpClient: HttpClient) { }

//   loginUser(user: Login): Observable<any> {
//     console.log(user);
//     return this.httpClient.post<any>(`${this.baseUrl}`, user);
//   }
// }

// // @Injectable({
// //   providedIn: 'root'
// // })
// // export class LoginService {
// //   baseUrl = "http://localhost:8080";

// //   constructor(private httpClient: HttpClient) { }

// //   loginUser(user: Login): Observable<object> {
// //     // ... existing code ...

// //     // Add the following line to return the result of the HTTP POST request
// //     return this.httpClient.post(`${this.baseUrl}/login`, user);
// //   }

// //   getAllUsers(): Observable<any> {
// //     return this.httpClient.get(`${this.baseUrl}/users`);
// //   }
// // }
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../component/login';


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  baseUrl="http://localhost:8080/login"
  constructor(private httpClient:HttpClient) { }

  loginUser(user:Login):Observable<object>{
    console.log(user);

      return this.httpClient.post(`${this.baseUrl}`,user);
    
  }
}
